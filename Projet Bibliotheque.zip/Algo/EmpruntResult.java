public class EmpruntResult {
    private boolean empruntReussi;
    private String message;
    private Livre livreEmprunte;

    public EmpruntResult(boolean empruntReussi, String message, Livre livreEmprunte) {
        this.empruntReussi = empruntReussi;
        this.message = message;
        this.livreEmprunte = livreEmprunte;
    }

    // Getters et setters

    public boolean isEmpruntReussi() {
        return empruntReussi;
    }

    public void setEmpruntReussi(boolean empruntReussi) {
        this.empruntReussi = empruntReussi;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Livre getLivreEmprunte() {
        return livreEmprunte;
    }

    public void setLivreEmprunte(Livre livreEmprunte) {
        this.livreEmprunte = livreEmprunte;
    }

    public boolean isSuccess() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'isSuccess'");
    }
}
