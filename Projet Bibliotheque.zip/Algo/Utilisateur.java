import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.Label;

public class Utilisateur {
    private static final int LIMITE_EMPRUNT = 2;

    private String nom;
    private int numeroIdentification;
    private ArrayList<Livre> livresEmpruntes;

    public Utilisateur(String nom, int numeroIdentification) {
        this.nom = nom;
        this.numeroIdentification = numeroIdentification;
        this.livresEmpruntes = new ArrayList<>();
    }

    // Méthode pour enregistrer un emprunt
    public void enregistrerEmprunt(Livre livre) throws LibraryException {
        EmpruntResult result = emprunterLivre(livre);
        if (!result.isSuccess()) {
            throw new LibraryException(result.getMessage());
        }
    }

    // Méthodes pour emprunter et retourner les livres
    public EmpruntResult emprunterLivre(Livre livre) {
        if (livresEmpruntes.size() >= LIMITE_EMPRUNT) {
            return new EmpruntResult(false, "Limite d'emprunt atteinte. Vous ne pouvez pas emprunter plus de livres.",
                    null);
        }
        if (livresEmpruntes.contains(livre)) {
            return new EmpruntResult(false, "Vous avez déjà emprunté ce livre.", null);
        }
        livresEmpruntes.add(livre);
        return new EmpruntResult(true, "Emprunt réussi", livre);
    }

    public void retournerLivre(Livre livre) {
        // Retire le livre de la liste des livres empruntés
        livresEmpruntes.remove(livre);
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getNumeroIdentification() {
        return numeroIdentification;
    }

    public void setNumeroIdentification(int numeroIdentification) {
        this.numeroIdentification = numeroIdentification;
    }

    public ArrayList<Livre> getLivresEmpruntes() {
        return livresEmpruntes;
    }

    // Méthode toString pour afficher les informations de l'utilisateur
    @Override
    public String toString() {
        return "Utilisateur{" +
                "nom='" + nom + '\'' +
                ", numeroIdentification=" + numeroIdentification +
                ", livresEmpruntes=" + livresEmpruntes +
                '}';
    }

    // Méthode pour retourner un livre
    public void retournerLivre(String ISBN, Bibliotheque bibliothèque) {
        Livre livre = bibliothèque.rechercherLivre(ISBN);
        if (livre != null && this.livresEmpruntes.remove(livre)) {
            bibliothèque.enregistrerRetour(this.numeroIdentification, ISBN);
            System.out.println("Le livre a été retourné avec succès.");
        } else {
            System.out.println("Cet utilisateur n'a pas emprunté le livre ou le livre n'existe pas.");
        }
    }

    private Label livresEmpruntesLabel;

    public Utilisateur(Label livresEmpruntesLabel) {
        this.livresEmpruntesLabel = livresEmpruntesLabel;
    }

    // Méthode pour afficher les livres empruntés
    public String afficherLivresEmpruntes() {
        StringBuilder livresEmpruntesText = new StringBuilder();
        if (livresEmpruntes.isEmpty()) {
            livresEmpruntesText.append("Vous n'avez emprunté aucun livre.");
        } else {
            livresEmpruntesText.append("Livres empruntés par ").append(nom).append(":\n");
            for (Livre livre : livresEmpruntes) {
                livresEmpruntesText.append(livre).append("\n");
            }
        }
        return livresEmpruntesText.toString();
    }

}
