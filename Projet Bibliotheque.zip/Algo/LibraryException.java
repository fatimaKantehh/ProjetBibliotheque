public class LibraryException extends Exception {
    // Constructeur qui prend un message d'erreur
    public LibraryException(String message) {
        super(message);
    }

    // Constructeur qui prend un message d'erreur et une cause
    public LibraryException(String message, Throwable cause) {
        super(message, cause);
    }
}
