import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import javafx.scene.control.Alert;

public class Bibliotheque {
    // Attributs
    private ArrayList<Livre> listeLivres;
    private HashMap<Integer, Utilisateur> utilisateurs;
    private HashMap<Utilisateur, ArrayList<Livre>> empruntsUtilisateurs;
    private List<Emprunt> emprunts = new ArrayList<>();

    // Constructeur
    public Bibliotheque() {
        listeLivres = new ArrayList<>();
        utilisateurs = new HashMap<>();
        empruntsUtilisateurs = new HashMap<>();
    }

    // Méthode pour ajouter un livre à la bibliothèque
    public void ajouterLivre(Livre livre) {
        listeLivres.add(livre);
    }

    // Méthode pour supprimer un livre de la bibliothèque
    public void supprimerLivre(String ISBN) {
        listeLivres.removeIf(livre -> livre.getISBN().equals(ISBN));
    }

    // Méthode pour modifier les détails d'un livre
    public boolean modifierLivre(String ISBN, Livre livreModifie) {
        for (int i = 0; i < listeLivres.size(); i++) {
            Livre livre = listeLivres.get(i);
            if (livre.getISBN().equals(ISBN)) {
                if (livreModifie instanceof Roman) {
                    if (livre instanceof Roman) {
                        Roman romanTrouve = (Roman) livre;
                        Roman romanModifie = (Roman) livreModifie;
                        romanTrouve.setGenre(romanModifie.getGenre());
                        romanTrouve.setEstUneSerie(romanModifie.EstUneSerie());
                        romanTrouve.setNumeroDansLaSerie(romanModifie.getNumeroDansLaSerie());
                    }
                } else if (livreModifie instanceof Essai) {
                    if (livre instanceof Essai) {
                        Essai essaiTrouve = (Essai) livre;
                        Essai essaiModifie = (Essai) livreModifie;
                        essaiTrouve.setDomaine(essaiModifie.getDomaine());
                        essaiTrouve.setMotsCles(essaiModifie.getMotsCles());
                    }
                } else if (livreModifie instanceof LivreAudio) {
                    if (livre instanceof LivreAudio) {
                        LivreAudio livreAudioTrouve = (LivreAudio) livre;
                        LivreAudio livreAudioModifie = (LivreAudio) livreModifie;
                        livreAudioTrouve.setDureeEnMinutes(livreAudioModifie.getDureeEnMinutes());
                        livreAudioTrouve.setNarrateur(livreAudioModifie.getNarrateur());
                    }
                }
                livre.setTitre(livreModifie.getTitre());
                livre.setAuteur(livreModifie.getAuteur());
                livre.setAnneePublication(livreModifie.getAnneePublication());
                return true;
            }
        }
        // Retourner false si aucun livre avec l'ISBN fourni n'a été trouvé
        return false;
    }

    // Méthode pour rechercher un livre par titre, auteur ou ISBN
    public Livre rechercherLivre(String recherche) {
        for (Livre livre : listeLivres) {
            if (livre.getTitre().equalsIgnoreCase(recherche) ||
                    livre.getAuteur().equalsIgnoreCase(recherche) ||
                    livre.getISBN().equalsIgnoreCase(recherche)) {
                return livre;
            }
        }
        return null;
    }

    // Méthode pour obtenir la liste des livres
    public ArrayList<Livre> getListeLivres() {
        return new ArrayList<>(listeLivres);
    }

    public Utilisateur rechercherUtilisateur(String nom, int numeroIdentifiant) {
        Utilisateur utilisateur = utilisateurs.get(numeroIdentifiant);
        if (utilisateur != null && utilisateur.getNom().equals(nom)) {
            return utilisateur;
        }
        if (utilisateur == null) {
            try {
                throw new LibraryException("Utilisateur non trouvé. Veuillez créer un compte.");
            } catch (LibraryException e) {
                e.printStackTrace();
            }
        }

        return utilisateur;
    }

    // Méthode pour enregistrer l'emprunt d'un livre par un utilisateur
    public boolean enregistrerEmprunt(String nom, int numeroIdentifiant, String ISBN) {
        Utilisateur utilisateur = rechercherUtilisateur(nom, numeroIdentifiant);
        Livre livre = rechercherLivre(ISBN);
        if (livre != null && utilisateur != null && !livre.estEmprunte()) {
            return true;
        }
        return false;
    }

    // Méthode pour enregistrer le retour d'un livre par un utilisateur
    public void enregistrerRetour(int numeroIdentification, String ISBN) {
        Utilisateur utilisateur = utilisateurs.get(numeroIdentification);
        if (utilisateur != null) {
            Livre livre = rechercherLivre(ISBN);
            ArrayList<Livre> livresEmpruntes = empruntsUtilisateurs.get(utilisateur);
            if (livre != null && livresEmpruntes != null) {
                livresEmpruntes.remove(livre);
            }
        }
    }

    // Méthode pour vérifier l'éligibilité d'un utilisateur à emprunter un livre
    public boolean verifierEligibilite(int numeroIdentification) {
        ArrayList<Livre> livresEmpruntes = empruntsUtilisateurs.get(utilisateurs.get(numeroIdentification));
        return livresEmpruntes != null && livresEmpruntes.size() < 3;
    }

    public String calculerStatistiques() {
        StringBuilder statistiques = new StringBuilder();

        // Calculer le livre le plus emprunté
        Livre livrePlusEmprunte = trouverLivrePlusEmprunte();
        statistiques.append("Livre le plus emprunté : ").append(livrePlusEmprunte.getTitre()).append("\n");

        // Calculer l'utilisateur le plus actif
        Utilisateur utilisateurPlusActif = trouverUtilisateurPlusActif();
        statistiques.append("Utilisateur le plus actif : ").append(utilisateurPlusActif.getNom()).append("\n");

        // Afficher les statistiques dans une boîte de dialogue
        afficherStatistiques(statistiques.toString());
        return null;
    }

    private void afficherStatistiques(String statistiques) {
        Alert alerte = new Alert(Alert.AlertType.INFORMATION);
        alerte.setTitle("Statistiques de la bibliothèque");
        alerte.setHeaderText(null);
        alerte.setContentText(statistiques);
        alerte.showAndWait();
    }

    // Méthode pour trouver le livre le plus emprunté
    private Livre trouverLivrePlusEmprunte() {
        HashMap<Livre, Integer> compteurEmprunts = new HashMap<>();

        // Parcourir tous les emprunts et compter le nombre d'emprunts pour chaque livre
        for (Emprunt emprunt : emprunts) {
            Livre livre = emprunt.getLivre();
            compteurEmprunts.put(livre, compteurEmprunts.getOrDefault(livre, 0) + 1);
        }
        // Trouver le livre avec le plus grand nombre d'emprunts
        Livre livrePlusEmprunte = null;
        int maxEmprunts = 0;
        for (Entry<Livre, Integer> entry : compteurEmprunts.entrySet()) {
            if (entry.getValue() > maxEmprunts) {
                livrePlusEmprunte = entry.getKey();
                maxEmprunts = entry.getValue();
            }
        }
        return livrePlusEmprunte;
    }

    // Méthode pour trouver l'utilisateur le plus actif
    private Utilisateur trouverUtilisateurPlusActif() {
        HashMap<Utilisateur, Integer> compteurEmprunts = new HashMap<>();
        for (Emprunt emprunt : emprunts) {
            Utilisateur utilisateur = emprunt.getUtilisateur();
            compteurEmprunts.put(utilisateur, compteurEmprunts.getOrDefault(utilisateur, 0) + 1);
        }
        // Trouver l'utilisateur avec le plus grand nombre d'emprunts
        Utilisateur utilisateurPlusActif = null;
        int maxEmprunts = 0;
        for (Entry<Utilisateur, Integer> entry : compteurEmprunts.entrySet()) {
            if (entry.getValue() > maxEmprunts) {
                utilisateurPlusActif = entry.getKey();
                maxEmprunts = entry.getValue();
            }
        }
        return utilisateurPlusActif;
    }

}
