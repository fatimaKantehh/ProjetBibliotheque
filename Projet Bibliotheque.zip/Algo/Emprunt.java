import java.time.LocalDate;

public class Emprunt {
    private Utilisateur utilisateur;
    private Livre livre;
    private LocalDate dateEmprunt;

    public Emprunt(Utilisateur utilisateur, Livre livre, LocalDate dateEmprunt) {
        this.utilisateur = utilisateur;
        this.livre = livre;
        this.dateEmprunt = dateEmprunt;
    }

    // Getters et setters

    public Utilisateur getUtilisateur() {
        return utilisateur;
    }

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
    }

    public Livre getLivre() {
        return livre;
    }

    public void setLivre(Livre livre) {
        this.livre = livre;
    }

    public LocalDate getDateEmprunt() {
        return dateEmprunt;
    }

    public void setDateEmprunt(LocalDate dateEmprunt) {
        this.dateEmprunt = dateEmprunt;
    }
}
